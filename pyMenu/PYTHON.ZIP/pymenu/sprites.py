#-*- coding: ISO-8859-1 -*-
# Ported to pyMenu from sprites.py by fraka7
__rcsid__ = '$Id: sprites.py 1470 2005-11-20 13:04:29Z fraca7 $'

import psp2d
import math, random, time
from common import *
from controller import *

class Sprite:
	def __init__(self, img_s):
		x = 1.0 * random.randrange(0, 480 - img_s.width, 1)
		y = 1.0 * random.randrange(0, 272 - img_s.height, 1)

		self.data = img_s, x, y
		self.w = img_s.width
		self.h = img_s.height

		self.u = random.random() * 3 - 1.5, random.random() * 3 - 1.5

	def nextFrame(self):
		x = self.data[1] + self.u[0]
		y = self.data[2] + self.u[1]

		if x + self.w >= 480 or x <= 0:
			self.u = -self.u[0], self.u[1]

		if y + self.h >= 272 or y <= 0:
			self.u = self.u[0], -self.u[1]

		self.data = self.data[0], x, y

def main():
	global screen
	img_s = psp2d.Image('sprite.png')
	sprites = [ Sprite(img_s) for unused in xrange(30) ]
	screen = psp2d.Screen()

	batch = psp2d.BlitBatch()
	for sprite in sprites:
		batch.add(sprite)

	batching = False

	while True:
		if batching:
			while True:
				screen.clear(psp2d.Color(0, 0, 0))

				for sprite in sprites:
					sprite.nextFrame()
				batch.blit()

				screen.swap()

				if padCircle("r"):
					batching = False
					time.sleep(0.2)
					return "exit"
					break
				elif padSquare("r"):
					return "change"
					break
		else:
			while True:
				screen.clear(psp2d.Color(0, 0, 0))

				for sprite in sprites:
					sprite.nextFrame()
					img_s, x, y = sprite.data
					screen.blit(img_s, dx = x, dy = y, blend = True)

				screen.swap()

				if padCircle("r"):
					batching = True
					time.sleep(0.2)
					return "exit"
					break
				elif padSquare("r"):
					return "change"
					break

if __name__ == '__main__':
	try:
		main()
	except KeyboardInterrupt:
		pass
	except:
		import traceback
		traceback.print_exc(file = file('trace.txt', 'w'))
