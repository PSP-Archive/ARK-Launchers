#! /usr/bin/env python
# V/HBL Python Menu
# by Acid_Snake

changelog = """
Version 0.1: Initial release
Version 0.1.1: EBOOT.PBP is now renamed to wmenu.bin
Version 0.2:
	Added possibility to view icon0.png
	Added ability to have 10 more backgrounds named bgx.png (where x is a number from 0 to 9)
	Cleared some unused code
Version 0.2.1:
	Fixed some bugs
	Sped up icon0.png loading by extracting them once
Version 0.2.2:
	Custom backgrounds can now be in .jpg format
	Fixed bug that crashed the menu if exiting after viewing help within game menu
	Added pyMenu version in help menu
Version 0.2.2.1:
	Removed unused modules
	Fix bug in PSVita
	Added compatibility with Motorstorm
Version 0.3:
	Finished the file manager
	Fixed constant MS reading problem
	Added code to look for and remove homebrews starting with __sce__ or _sce_
	Created a complete version of the menu, being toggled on/off with square button (in main menu)
	Created API for easier coding
	Re-structured the entire code
	Made pyMenu more expandible
	Ported to PRO
	Ported to CEF
	Added Music Player for MP3 files
	Added Picture Viewer
	Added Plugin Manager
	Added Python Collection
	Added FTP server made by Coldbird
	The last played homebrew can be directly booted by pressing circle in the main menu
Version 0.3.1:
	PSN apps are now supported in the CEF version
	Fixed bug when the iso folder doesn't exist
	In the browser, when a file/folder has more than 20 characters, the last remaining characters are replaced by ...
	The browser will now show the file size in Bytes, KB, MB or GB (depending on the file size)
	The menu and browser's scrolling speed has been improved
	When canceling the browser's file operarions, it will go back to the previous folder instead of going back to ms0:/
Version 0.3.2:
	Fixed keytone bug that made the menu crash "randomly"
"""
print("pyMenu 0.3\n")

#import common, icon, img, menu, psptools, unzip
from define import *
from common import *
from icon import *
from img import *
from menu import *
from psptools import *
from unzip import *
from savedata import *
from browser import *
from game import *
from api import api
from picture import *
from music import *
from controller import *
import traceback, sys, iso, plugin_manager, collection
used_menu = main_menu
menu = None

print("Running in: " + version)

def menu_adv():
	def go():
		reload(define)
		selection = menu.get()
		if selection == language[1]:
			save_convert()
			menu_adv()
		elif selection == language[0]:
			game_select()
			menu_adv()
		elif selection == "ISO":
			iso.iso_menu()
			menu_adv()
		elif selection == language[2]:
			root, dirs, files = os.walk(start_path).next()
			browse = dirs+files
			if browse == []: browse = ["<empty>"]
			browser_menu().file_browser(browse, root)
			reload(define) # Dirty fix :P
			menu_adv()
		elif selection == "PSP Tools":
			psptools().menu()
			menu_adv()
		elif selection == language[3]:
			pic_menu()
			menu_adv()
		elif selection == language[4]:
			music_menu()
			menu_adv()
		elif selection == language[5]:
			plugin_manager.init()
			menu_adv()
		elif selection == language[6]:
			collection.init()
			menu_adv()
		elif selection == "FTP":
			file1 = open("ms0:/path.txt","w")
			file2 = open("ms0:/mode.txt","w")
			file1.write(os.getcwd()+"/FTP.PBP\n")
			file2.write("HOMEBREW_APP\n")
			file1.close()
			file2.close()
			raise SystemExit
	options = [
language[0],
"ISO",
language[1],
language[2],
"PSP Tools",
language[3],
language[4],
language[5],
language[6],
"FTP"
]
	if version == "HBL":
		options.remove("ISO")
		options.remove(language[5])
	if version == "HBL" or os.path.exists("ftp.pbp") == False:
		options.remove("FTP")
	opt_pos = 1
	img3.blit(img)
	menu.set_clear("plain")
	menu.init(options)
	x4 = True
	while x4 == True:
		if padDown(0):
			menu.down()
		elif padUp(0):
			menu.up()
		elif padCross("r"):
			x4 = False
			go()
		elif padCircle("r"):
			x4 = False
			raise SystemExit
		elif padSelect("r"):
			x4 = False
			help()
			menu_adv()
		elif padSquare("r"):
			x4 = False
			select_menu()

def select_menu():
	# Read the default configuration and choose the correct menu style
	global menu, used_menu
	if used_menu == "complete":
		used_menu = "simple"
		menu = adv_menu()
		menu_adv()
	elif used_menu == "simple":
		used_menu = "complete"
		menu = simple_menu()
		menu_adv()

if api == False:
	#show_loading()
	check_icons()
	select_menu()
elif api == True:
	print "pyMenu API loaded"
