# by Acid_Snake
from define import *
from common import *
from controller import *
import os

class psptools:
	def dir_fix(self):
		print("Scanning missing directories and files...\n")
		missing = 0
		if os.path.isdir("ms0:/MP_ROOT") == False:
			os.mkdir("ms0:/MP_ROOT")
			print("ms0:/MP_ROOT missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/MP_ROOT/100MNV01") == False:
			os.mkdir("ms0:/MP_ROOT/100MNV01")
			print("ms0:/MP_ROOT/100MNV01 missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/MP_ROOT/101ANV01") == False:
			os.mkdir("ms0:/MP_ROOT/101ANV01")
			print("ms0:/MP_ROOT/101ANV01 missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP") == False:
			os.mkdir("ms0:/PSP")
			print("ms0:/PSP missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP/GAME") == False:
			os.mkdir("ms0:/PSP/GAME")
			print("ms0:/PSP/GAME missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP/GAME150") == False:
			os.mkdir("ms0:/PSP/GAME150")
			print("ms0:/PSP/GAME150 missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP/SAVEDATA") == False:
			os.mkdir("ms0:/PSP/SAVEDATA")
			print("ms0:/PSP/SAVEDATA missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP/PHOTO") == False:
			os.mkdir("ms0:/PSP/PHOTO")
			print("ms0:/PSP/PHOTO missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP/VIDEO") == False:
			os.mkdir("ms0:/PSP/VIDEO")
			print("ms0:/PSP/VIDEO missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP/THEME") == False:
			os.mkdir("ms0:/PSP/THEME")
			print("ms0:/PSP/THEME missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP/COMMON") == False:
			os.mkdir("ms0:/PSP/COMMON")
			print("ms0:/PSP/COMMON missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP/SYSTEM") == False:
			os.mkdir("ms0:/PSP/SYSTEM")
			print("ms0:/PSP/SYSTEM missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP/RSSCH") == False:
			os.mkdir("ms0:/PSP/RSSCH")
			print("ms0:/PSP/RSSCH missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP/RSSCH/IMPORT") == False:
			os.mkdir("ms0:/PSP/RSSCH/IMPORT")
			print("ms0:/PSP/RSSCH/IMPORT missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PSP/MUSIC") == False:
			os.mkdir("ms0:/PSP/MUSIC")
			print("ms0:/PSP/MUSIC missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/VIDEO") == False:
			os.mkdir("ms0:/VIDEO")
			print("ms0:/VIDEO missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/MUSIC") == False:
			os.mkdir("ms0:/MUSIC")
			print("ms0:/MUSIC missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/PICTURE") == False:
			os.mkdir("ms0:/PICTURE")
			print("ms0:/PICTURE missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/ISO") == False:
			os.mkdir("ms0:/ISO")
			print("ms0:/ISO missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/ISO/VIDEO") == False:
			os.mkdir("ms0:/ISO/VIDEO")
			print("ms0:/ISO/VIDEO missing...fixed\n")
			missing = missing + 1
		if os.path.isdir("ms0:/SEPLUGINS") == False:
			os.mkdir("ms0:/SEPLUGINS")
			print("ms0:/SEPLUGINS missing...fixed\n")
			missing = missing + 1
		try: open("ms0:/SEPLUGINS/game.txt", "r").close()
		except:
			open("ms0:/SEPLUGINS/game.txt", "w").close()
			print("ms0:/SEPLUGINS/game.txt missing...fixed\n")
			missing = missing + 1
		try: open("ms0:/SEPLUGINS/pops.txt", "r").close()
		except:
			open("ms0:/SEPLUGINS/pops.txt", "w").close()
			print("ms0:/SEPLUGINS/pops.txt missing...fixed\n")
			missing = missing + 1
		try: open("ms0:/SEPLUGINS/vsh.txt", "r").close()
		except:
			open("ms0:/SEPLUGINS/vsh.txt", "w").close()
			print("ms0:/SEPLUGINS/vsh.txt missing...fixed\n")
			missing = missing + 1
		try: open("ms0:/SEPLUGINS/game150.txt", "r").close()
		except:
			open("ms0:/SEPLUGINS/game150.txt", "w").close()
			print("ms0:/SEPLUGINS/game150.txt missing...fixed\n")
			missing = missing + 1
		try: open("ms0:/SEPLUGINS/version.txt", "r").close()
		except:
			open("ms0:/SEPLUGINS/version.txt", "w").write("""release:9.90:
build:6666,0,3,1,0:builder@vsh-build6
system:54865@release_610,0x09090010:
vsh:p6501@release_610,v55286@release_610,20121221:
target:1:WorldWide
""")
			print("ms0:/SEPLUGINS/version.txt missing...fixed\n")
			missing = missing + 1
		try: open("ms0:/MEMSTICK.IND", "r").close()
		except:
			open("ms0:/MEMSTICK.IND", "w").close()
			print("ms0:/MEMSTICK.IND missing...fixed\n")
			missing = missing + 1
		print(language[43]+" "+str(missing)+"\n")
		msg(str(missing)+" "+language[44])
		x12 = True
		while x12 == True:
			if padCross("r"):
				x12 = False
				self.menu()
	def pixel_fix(self):
		x12 = True
		print("pixel fixer started\n")
		while x12 == True:
			img3.clear(WHITE_COLOR)
			scr.blit(img3)
			scr.swap()
			self.delay()
			img3.clear(RED_COLOR)
			scr.blit(img3)
			scr.swap()
			self.delay()
			img3.clear(GREEN_COLOR)
			scr.blit(img3)
			scr.swap()
			self.delay()
			img3.clear(BLUE_COLOR)
			scr.blit(img3)
			scr.swap()
			self.delay()
			img3.clear(YELLOW_COLOR)
			scr.blit(img3)
			scr.swap()
			self.delay()
			if padTriangle("r"):
				x12 = False
				print("pixel fixer ended by user\n")
				self.menu()
	def button_test(self):
		print("button tester started...\n")
		x0 = True
		while x0 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[45])
			scr.blit(img3)
			scr.swap()
			if padCross("r"):
				print("cross button ok\n")
				x0 = False
		x1 = True
		while x1 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[46])
			scr.blit(img3)
			scr.swap()
			if padCircle("r"):
				print("circle button ok\n")
				x1 = False
		x2 = True
		while x2 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[47])
			scr.blit(img3)
			scr.swap()
			if padSquare("r"):
				print("square button ok\n")
				x2 = False
		x3 = True
		while x3 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[48])
			scr.blit(img3)
			scr.swap()
			if padTriangle("r"):
				print("triangle button ok\n")
				x3 = False
		x4 = True
		while x4 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[49])
			scr.blit(img3)
			scr.swap()
			if padRT("r"):
				print("right trigger button ok\n")
				x4 = False
		x5 = True
		while x5 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[50])
			scr.blit(img3)
			scr.swap()
			if padLT("r"):
				print("left trigger button ok\n")
				x5 = False
		x6 = True
		while x6 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[51])
			scr.blit(img3)
			scr.swap()
			if padStart("r"):
				print("start button ok\n")
				x6 = False
		x7 = True
		while x7 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[52])
			scr.blit(img3)
			scr.swap()
			if padSelect("r"):
				print("select button ok\n")
				x7 = False
		x8 = True
		while x8 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[53])
			scr.blit(img3)
			scr.swap()
			if padLeft("r"):
				print("left button ok\n")
				x8 = False
		x9 = True
		while x9 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[54])
			scr.blit(img3)
			scr.swap()
			if padRight("r"):
				print("right button ok\n")
				x9 = False
		x10 = True
		while x10 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[55])
			scr.blit(img3)
			scr.swap()
			if padUp("r"):
				print("up button ok\n")
				x10 = False
		x11 = True
		while x11 == True:
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[56])
			scr.blit(img3)
			scr.swap()
			if padDown("r"):
				print("down button ok\n")
				x11 = False
	
		wait = 10
		while wait > 0:
			delay()
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 60, language[57])
			scr.blit(img3)
			scr.swap()
			wait -= 1
			if padCross():
				wait = 0
				print("problem with cross button\n")
				info = language[58]
			elif padCircle():
				wait = 0
				print("problem with circle button\n")
				info = language[59]
			elif padSquare():
				wait = 0
				print("problem with square button\n")
				info = language[60]
			elif padTriangle():
				wait = 0
				print("problem with triangle button\n")
				info = language[61]
			elif padRT():
				wait = 0
				print("problem with R-trigger button\n")
				info = language[62]
			elif padLT():
				wait = 0
				print("problem with L-trigger button\n")
				info = language[63]
			elif padStart():
				wait = 0
				print("problem with start button\n")
				info = language[64]
			elif padSelect():
				wait = 0
				print("problem with select button\n")
				info = language[65]
			elif padUp():
				wait = 0
				print("problem with up button\n")
				info = language[66]
			elif padLeft():
				wait = 0
				print("problem with left button\n")
				info = language[67]
			elif padRight():
				wait = 0
				print("problem with right button\n")
				info = language[68]
			elif padDown():
				wait = 0
				print("problem with down button\n")
				info = language[69]
			else:
				print("buttons seem ok\n")
				info = language[70]
		msg(info)
		x12 = True
		while x12 == True:
			if padCross("r"):
				x12 = False
				self.menu()
	def delay(self):
		# time.sleep alternative
		time_lapse = 0.05
		time_start = time.time()
		time_end = (time_start + time_lapse)
		while time_end > time.time():
			pass
	def menu(self):
		def draw_screen():
			img_clear()
			img3.clear(CLEAR_COLOR)
			fnt2.drawText(img3, 0, 0, "PSPTools Lite")
			fnt2.drawText(img3, 0, 90, tools[tools_pos])
			scr.blit(img3)
			scr.swap()
		tools = [language[40], language[41],language[42]]
		tools_pos = 0
		draw_screen()
		xy = True
		while xy == True:
			if padDown(0):
				try:
					tools_pos += 1
					draw_screen()
				except:
					tools_pos = 0
					draw_screen()
			if padUp(0):
				try:
					tools_pos -= 1
					draw_screen()
				except:
					tools_pos = 0
					draw_screen()
			if padCross("r"):
				xy = False
				if tools[tools_pos] == language[40]: self.dir_fix()
				elif tools[tools_pos] == language[41]: self.pixel_fix()
				elif tools[tools_pos] == language[42]: self.button_test()
			elif padCircle("r"):
				xy = False
