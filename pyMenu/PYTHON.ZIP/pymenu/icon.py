# ICON0.PNG extractor
# Since psp2d only opens images in files (not in buffer) we need to extract all the icons
# this is done only once and it's pretty fast so no need to change it for now
from define import *
import os, traceback, re, extract_icon0

def get_size(OPEN_FILE, BYTE_AMOUNT = 4):
	#Get the offset size from an opened file.
	#OPEN_FILE is the opened file that we want to read from.
	#BYTE_AMOUNT can be either two or four
	#depending on the offset we're working with,
	#it is four by default.

	BYTE_ONE = ord(OPEN_FILE.read(1))
	BYTE_TWO = ord(OPEN_FILE.read(1)) * 256
	if BYTE_AMOUNT == 4:
		BYTE_THREE = ord(OPEN_FILE.read(1)) * 256 * 256
		BYTE_FOUR = ord(OPEN_FILE.read(1)) * 256 * 256 * 256
		return BYTE_ONE + BYTE_TWO + BYTE_THREE + BYTE_FOUR
	return BYTE_ONE + BYTE_TWO
#End of get_size

def extract_image(EBOOT_SOURCE, EXTRACT_DEST=input, IMAGE_TYPE = "icon0"):
	#Extract an image from an eboot.
	#EBOOT_SOURCE can either be an open file or a path to the eboot.
	#EXTRACT_DEST is the path to extract to.
	#IMAGE_TYPE can be either "icon0", "pic0" or "pic1".
	if str(type(EBOOT_SOURCE)) == "<type 'str'>":
		for i in eboot_names:
			if os.path.exists(EBOOT_SOURCE+i) == True: EBOOT_FILE = open(EBOOT_SOURCE+i,"rb")
		if EXTRACT_DEST == input: EXTRACT_DEST = os.path.dirname(EBOOT_SOURCE) + "/icon0.png"
	elif str(type(EBOOT_SOURCE)) == "<type 'file'>":
		EBOOT_FILE = EBOOT_SOURCE
		if EXTRACT_DEST == input: EXTRACT_DEST = os.path.dirname(EBOOT_SOURCE.name) + "/icon0.png"
	EBOOT_FILE.seek(0)
	if EBOOT_FILE.read(4) != chr(0) + "PBP":
		return False
	if IMAGE_TYPE == "icon0":
		EBOOT_FILE.seek(12)
		EBOOT_ICON0_START = get_size(EBOOT_FILE)
		EBOOT_ICON0_SIZE = get_size(EBOOT_FILE) - EBOOT_ICON0_START
		if EBOOT_ICON0_SIZE == 0:
			EBOOT_FILE.close()
			return False
		EBOOT_FILE.seek(EBOOT_ICON0_START)
		EBOOT_ICON0_MAGIC = EBOOT_FILE.read(4)
		EBOOT_FILE.seek(EBOOT_ICON0_START)
		if EBOOT_ICON0_MAGIC != chr(137) + "PNG":
			EBOOT_FILE.close()
			return False
		ICON0_FILE = open(EXTRACT_DEST,"wb")
		ICON0_FILE.write(EBOOT_FILE.read(EBOOT_ICON0_SIZE))
		ICON0_FILE.close()
		EBOOT_FILE.close()
		return True
	elif IMAGE_TYPE == "pic0":
		EBOOT_FILE.seek(20)
		EBOOT_PIC0_START = get_size(EBOOT_FILE)
		EBOOT_PIC0_SIZE = get_size(EBOOT_FILE) - EBOOT_PIC0_START
		if EBOOT_PIC0_SIZE == 0:
			EBOOT_FILE.close()
			return False
		EBOOT_FILE.seek(EBOOT_PIC0_START)
		EBOOT_PIC0_MAGIC = EBOOT_FILE.read(4)
		EBOOT_FILE.seek(EBOOT_PIC0_START)
		if EBOOT_PIC0_MAGIC != chr(137) + "PNG":
			EBOOT_FILE.close()
			return False
		PIC0_FILE = open(EXTRACT_DEST,"wb")
		PIC0_FILE.write(EBOOT_FILE.read(EBOOT_PIC0_SIZE))
		PIC0_FILE.close()
		EBOOT_FILE.close()
		return True
	elif IMAGE_TYPE == "pic1":
		EBOOT_FILE.seek(24)
		EBOOT_PIC1_START = get_size(EBOOT_FILE)
		EBOOT_PIC1_SIZE = get_size(EBOOT_FILE) - EBOOT_PIC1_START
		if EBOOT_PIC1_SIZE == 0:
			EBOOT_FILE.close()
			return False
		EBOOT_FILE.seek(EBOOT_PIC1_START)
		EBOOT_PIC1_MAGIC = EBOOT_FILE.read(4)
		EBOOT_FILE.seek(EBOOT_PIC1_START)
		if EBOOT_PIC1_MAGIC != chr(137) + "PNG":
			EBOOT_FILE.close()
			return False
		PIC1_FILE = open(EXTRACT_DEST,"wb")
		PIC1_FILE.write(EBOOT_FILE.read(EBOOT_PIC1_SIZE))
		PIC1_FILE.close()
		EBOOT_FILE.close()
		return True

def extract_icon(path_to_eboot):
	# Extract icon0 from eboot
	try:
		for i in eboot_names:
			if os.path.exists(path_to_eboot+i) == True: x = open(path_to_eboot+i).read(256000)
		r = re.compile("504e47(.*?)49454e44ae426082")
		m = r.search(x)
		icon = "89" + m.group()
		y = open(path_to_eboot+"icon0.png","w")
		y.write(icon.decode("hex"))
		y.close()
		x = ""
		icon = ""
		r = ""
		m = ""
	except:
		open(path_to_eboot+"/icon0.png","wb").write(open("noicon.png","rb").read())
		x = ""
		icon = ""
		r = ""
		m = ""

def check_icons():
	# Recursively check if icons are extracted, if not, extract them
	root, dirs, files = os.walk("ms0:/PSP/GAME").next()
	for i in dirs:
		if os.path.exists(root+"/"+i+"/icon0.png") == False:
			try: extract_image(root+"/"+i+"/")
			except: extract_icon(root+"/"+i+"/")
	if os.path.exists(iso_path) == True:
		root, dirs, files = os.walk(iso_path).next()
		for i in files:
			if os.path.exists("ms0:/pygame/tmp/"+i+".png") == False:
				try: extract_icon0.extract_icon0(root+"/"+i, "ms0:/pygame/tmp/"+os.path.basename(root+"/"+i)+".png")
				except: pass
