# This is where all the global variables are defined, do not mess with this unless you know what you're doing
import psp2d, random
from config import *

WHITE_COLOR = psp2d.Color(255,255,255)
CLEAR_COLOR = psp2d.Color(0,0,0)
TRANS_COLOR = psp2d.Color(0,0,0,255)
RED_COLOR   = psp2d.Color(255, 0, 0)
GREEN_COLOR = psp2d.Color(0, 255, 0)
BLUE_COLOR  = psp2d.Color(0,50,255)
YELLOW_COLOR  = psp2d.Color(255,255,0)
COLORS = [CLEAR_COLOR, RED_COLOR, GREEN_COLOR, BLUE_COLOR, YELLOW_COLOR]
#BG = ["background.png"]
BG = [default_bg]
possible_bgs = [0,1,2,3,4,5,6,7,8,9]
for i in possible_bgs:
	try :
		open("bg"+str(i)+".png","rb").close()
		BG = BG.__add__(["bg"+str(i)+".png"])
	except:
		try:
			open("bg"+str(i)+".jpg","rb").close()
			BG = BG.__add__(["bg"+str(i)+".jpg"])
		except: False
RANDOM_BG = random.choice(BG)
scr = psp2d.Screen()
scr2 = psp2d.Screen()
fnt = psp2d.Font("font.png")
fnt2 = psp2d.Font("font2.png")
fnt3 = psp2d.Font("font3.png")
img = psp2d.Image(RANDOM_BG)
img2 = input
img3 = psp2d.Image(480, 272)
img4 = psp2d.Image(100, 200)
img5 = psp2d.Image(480, 272)
load_img = psp2d.Image("load.png")
clipboard = [input,input]
entries_pos = [20,0,0]
eboot_names = ["EBOOT.PBP", "wmenu.bin", "FBOOT.PBP", "VBOOT.PBP"]
try: language = open("LANG_"+default_language+".TXT", "r").readlines()
except: language = open("LANG"+default_language+".TXT", "r").readlines()
