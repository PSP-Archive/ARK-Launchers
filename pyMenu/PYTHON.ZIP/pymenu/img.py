# Different refresh functions
from define import *
import os

def img_clear():
	# Refresh the generic screen
	img3.blit(img)

def img_clear_game(the_icon):
	# Refresh the screen for the Simple Game Menu, showing icon0
	global img
	if os.path.exists(the_icon) == True:
		img2 = psp2d.Image(the_icon)
	else: img2 = psp2d.Image("noicon.png")
	img3.blit(img)
	img3.blit(img2,dx=10,dy=30)
	return img2, img3

def img_clear_game_adv(the_icon):
	# Refresh the screen for the Complete Game Menu, showing icon0
	global img2
	if os.path.exists(the_icon) == True:
		img2 = psp2d.Image(the_icon)
	else: img2 = psp2d.Image("noicon.png")
	#img5.blit(img)
	img5.blit(img2, dx=200, dy=100)
	return img2, img5

def img_clear_all():
	# Refresh the screen, leaving it black
	img3.clear(CLEAR_COLOR)
