# Extract icon0 from iso/cso
# by qwikrazor87
import os, zlib, math

def ceil(num):
	return int(math.ceil(num))

def read_size(open_file, read_size = 4):
	#function for getting little endian offset size
	byte_one = ord(open_file.read(1))
	byte_two = ord(open_file.read(1)) * 256
	if read_size == 2:
		return byte_one + byte_two
	byte_three = ord(open_file.read(1)) * 256 * 256
	byte_four = ord(open_file.read(1)) * 256 * 256 * 256
	return byte_one + byte_two + byte_three + byte_four
#End of read_size

def extract_icon0(path, extract_path):
	file = open(path,"rb")
	cso_magic = file.read(4)
	file.seek(32768)
	iso_magic = file.read(6)
	if cso_magic == "CISO":
		file.seek(16)
		block_size = read_size(file)
		start_read = (32768 / block_size) * 4 + 24
		file.seek(start_read)
		fo = read_size(file)
		fs = read_size(file)
		file.seek(fo)
		d_data = zlib.decompress(file.read(fs), -15)
		b_one = ord(d_data[158:159])
		b_two = ord(d_data[159:160])
		b_three = ord(d_data[160:161])
		b_four = ord(d_data[161:162])
		start = (b_one + b_two + b_three + b_four) * 4
		file.seek(start + 28)
		offset = read_size(file)
		size = read_size(file) - offset
		file.seek(offset)
		d_data = zlib.decompress(file.read(size), -15)
		pos = 0
		while True:
			if pos > block_size:
				return False
			if d_data[pos:pos + 9] == "ICON0.PNG":
				extract_pic = open(extract_path, 'wb')
				pos = pos - 31
				b_one = ord(d_data[pos:pos + 1])
				b_two = ord(d_data[pos + 1:pos + 2]) * 256
				b_three = ord(d_data[pos + 2:pos + 3]) * 256 * 256
				b_four = ord(d_data[pos + 3:pos + 4]) * 256 * 256 * 256
				b_offset = (b_one + b_two + b_three + b_four) * 4 + 24
				b_one = ord(d_data[pos + 8:pos + 9])
				b_two = ord(d_data[pos + 9:pos + 10]) * 256
				b_three = ord(d_data[pos + 10:pos + 11]) * 256 * 256
				b_four = ord(d_data[pos + 11:pos + 12]) * 256 * 256 * 256
				b_size = (b_one + b_two + b_three + b_four)
				b_iter = ceil(b_size/2048.0) + 1
				trail_size = block_size - (((b_iter - 1) * block_size) - b_size)
				file.seek(b_offset)
				for x in xrange(1, b_iter):
					cur_pos = file.tell()
					b_one = ord(file.read(1))
					b_two = ord(file.read(1)) * 256
					b_three = ord(file.read(1)) * 256 * 256
					b_four = ord(file.read(1)) * 256 * 256 * 256
					is_compressed = "yes"
					if b_four >= 2147483648:
						is_compressed = "no"
						b_four = b_four - 2147483648
					offset = b_one + b_two + b_three + b_four
					b_one = ord(file.read(1))
					b_two = ord(file.read(1)) * 256
					b_three = ord(file.read(1)) * 256 * 256
					b_four = ord(file.read(1)) * 256 * 256 * 256
					if b_four >= 2147483648:
						b_four = b_four - 2147483648
					size = (b_one + b_two + b_three + b_four) - offset
					file.seek(offset)
					if is_compressed == "yes":
						if x < b_iter - 1:
							extract_pic.write(zlib.decompress(file.read(size), -15))
						else:
							extract_pic.write(zlib.decompress(file.read(size), -15)[0:trail_size])
					else:
						extract_pic.write(file.read(size))
					file.seek(cur_pos + 4)
				break
			pos += 1
		extract_pic.close()
		file.close()
	elif iso_magic == chr(1) + "CD001":
		file.seek(32926)
		dir_lba = read_size(file)
		file.seek(file.tell() + 4)
		block_size = read_size(file)
		dir_start = dir_lba * block_size + block_size
		file.seek(dir_start)
		search_end = file.tell() + 2048
		while True:
			cur_pos = file.tell()
			entry_size = ord(file.read(1))
			if entry_size == 0 or file.tell() >= search_end:
				file.close()
				return False
			file.seek(cur_pos + 32)
			name_size = ord(file.read(1))
			entry_name = file.read(name_size)
			if entry_name == "ICON0.PNG":
				file.seek(cur_pos + 2)
				icon0_offset = read_size(file) * block_size
				file.seek(file.tell() + 4)
				icon0_size = read_size(file)
				if icon0_size == 0:
					file.close()
					return False
				file.seek(icon0_offset)
				extract_pic = open(extract_path, 'wb')
				extract_pic.write(file.read(icon0_size))
				extract_pic.close()
				file.close()
				return True
			file.seek(cur_pos + entry_size)
	else:
		file.close()
		return False
#End of extract_icon0
