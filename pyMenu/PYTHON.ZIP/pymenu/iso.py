# Simple ISO interface
# by Acid_Snake
from pymenu.define import *
from pymenu.menu import *
from pymenu.common import *
from pymenu.controller import *
import os, iso_check

if main_menu == "complete": menu = adv_menu()
elif main_menu == "simple": menu = simple_menu()

def iso_boot(path):
	file1 = open("ms0:/path.txt","w")
	file2 = open("ms0:/mode.txt","w")
	if os.path.exists(path) == True:
		file1.write(path+"\n")
		file1.close()
		file2.write(iso_check.is_patched(path))
		file2.close()
		msg(language[20])
		raise SystemExit
	else: pass

def iso_menu():
	if os.path.exists(iso_path) == True:
		root, dirs, files = os.walk(iso_path).next()
		if files == []:
			txt([language[29]])
			x = False
		else:
			if game_menu == "icon": menu.set_clear("icon_iso")
			elif game_menu == "plain": menu.set_clear("plain")
			menu.init(files)
			x = True
	else:
		try:
			os.mkdir(iso_path)
			iso_menu()
		except:
			x = False
	while x == True:
		if padDown(0):
			menu.down()
		elif padUp(0):
			menu.up()
		elif padCross("r"):
			x = False
			path = root+"/"+menu.get()
			iso_boot(path)
		elif padCircle("r"):
			x = False
