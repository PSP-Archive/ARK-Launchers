# File browser with full copy, cut, paste and delete support
# It can also detect and load different file types
# by Acid_Snake
from define import *
from img import *
from common import *
from unzip import *
from controller import *
import os, shutil, text_reader, iso_check

def delay():
	# time.sleep alternative
	time_lapse = 0.07
	time_start = time.time()
	time_end = (time_start + time_lapse)
	while time_end > time.time():
		pass

def load_file(path):
	base, ext = os.path.splitext(path)
	if open(path,"r").read(4) == "\x00PBP":
		file1 = open("ms0:/path.txt","w")
		file1.write(path+"\n")
		file1.close()
		file2 = open("ms0:/mode.txt","w")
		file2.write("HOMEBREW_APP\n")
		file2.close()
		msg(language[20])
		raise SystemExit
	elif ext == ".png" or ext == ".jpg":
		picture(path)
		delay()
		return True
	elif ext == ".zip":
		msg(language[21])
		os.mkdir(base)
		unzipper = unzip()
		unzipper.extract(path, base)
		return True
	elif ext == ".mp3":
		music(path)
		return True
	elif ext == ".iso" or ext == ".cso":
		file1 = open("ms0:/path.txt","w")
		file1.write(path+"\n")
		file1.close()
		file2 = open("ms0:/mode.txt","w")
		file2.write(iso_check.is_patched(path))
		file2.close()
		msg(language[20])
		raise SystemExit
	elif ext == ".txt":
		text_reader.text_reader(path)
		return True
	else: return False

class browser_menu:
	global entries, clipboard, entries_pos

	def browser_help():
		img_clear()
		img.clear(CLEAR_COLOR)
		fnt.drawText(img, 0, 0, language[9])
		fnt.drawText(img, 0, 30, language[10])
		fnt.drawText(img, 0, 60, language[11])
		fnt.drawText(img, 0, 90, language[12])
		scr.blit(img)
		scr.swap()
		x1 = True
		while x1 == True:
			if padSelect("r"):
				x1 = False
				img_clear()
				root, dirs, files = os.walk(start_path).next()
				browse = dirs+files
				self.file_browser(browse, root)

	def file_options(self,browse, root):
		global clipboard
		#img3.blit(img4)
		#img_clear()
		def show_options():
			fnt.drawText(img3, 0, 30, "X    "+language[13])
			fnt.drawText(img3, 0, 60, "()    "+language[14])
			fnt.drawText(img3, 0, 90, "[]    "+language[15])
			fnt.drawText(img3, 0, 120, "/\    "+language[16])
			fnt.drawText(img3, 0, 150, "R    "+language[17])
			scr.blit(img3)
			scr.swap()
		def copy(browse, root):
			global clipboard
			if root != "ms0:/":
				clipboard = [root+"/"+browse,0]
			elif root == "ms0:/":
				clipboard = [root+browse,0]
			root, dirs, files = os.walk(start_path).next()
			browse = dirs+files
			self.file_browser(browse, root)
		def cut(browse, root):
			global clipboard
			if root != "ms0:/":
				clipboard = [root+"/"+browse,1]
			elif root == "ms0:/":
				clipboard = [root+browse,1]
			root, dirs, files = os.walk(start_path).next()
			browse = dirs+files
			self.file_browser(browse, root)
		def paste(browse, root):
			global clipboard
			if clipboard[1] == 0:
				clip_base = os.path.basename(clipboard[0])
				if root != "ms0:/":
					if os.path.isdir(clipboard[0]) == True:
						copy_tree(clipboard[0],root+"/"+clip_base)
					else: shutil.copyfile(clipboard[0],root+"/"+clip_base)
				elif root == "ms0:/":
					if os.path.isdir(clipboard[0]) == True:
						copy_tree(clipboard[0],root+clip_base)
					else: shutil.copyfile(clipboard[0],root+clip_base)
			elif clipboard[1] == 1:
				clip_base = os.path.basename(clipboard[0])
				if root != "ms0:/":
					if os.path.isdir(clipboard[0]) == True:
						copy_tree(clipboard[0],root+"/"+clip_base)
						shutil.rmtree(clipboard[0])
					else:
						shutil.copyfile(clipboard[0],root+"/"+clip_base)
						os.remove(clipboard[0])
				elif root == "ms0:/":
					if os.path.isdir(clipboard[0]) == True:
						copy_tree(clipboard[0],root+clip_base)
						shutil.rmtree(clipboard[0])
					else:
						shutil.copyfile(clipboard[0],root+clip_base)
						os.remove(clipboard[0])
			root, dirs, files = os.walk(start_path).next()
			browse = dirs+files
			self.file_browser(browse, root)
		def delete(browse, root):
			if root != "ms0:/":
				try: shutil.rmtree(root+"/"+browse)
				except: os.remove(root+"/"+browse)
			elif root == "ms0:/":
				try: shutil.rmtree(root+browse)
				except: os.remove(root+browse)
			root, dirs, files = os.walk(start_path).next()
			browse = dirs+files
			self.file_browser(browse, root)
		def cancel():
			root_, dirs, files = os.walk(root).next()
			browse = dirs+files
			self.file_browser(browse, root_)
		show_options()
		x2 = True
		while x2 == True:
			if padCross("r"):
				x2 = False
				copy(browse, root)
			elif padCircle("r"):
				x2 = False
				cut(browse, root)
			elif padSquare("r"):
				x2 = False
				paste(browse, root)
			elif padTriangle("r"):
				x2 = False
				delete(browse, root)
			elif padRT("r"):
				x2 = False
				cancel()

	def show_items(self,entry,root):
		img_clear_all()
		global offset2
		offset = 150
		offset2 = 110
		if clipboard[0] != input:
			if clipboard[1] == 0:
				fnt.drawText(img3, 10, 220, "Clipboard: "+clipboard[0]+" , mode: "+language[13])
			if clipboard[1] == 1:
				fnt.drawText(img3, 10, 220, "Clipboard: "+clipboard[0]+" , mode: "+language[14])
		fnt.drawText(img3, 10, 235, language[18])
		fnt.drawText(img3, 10, 250, root)
		for i in entry:
			num = entry.index(i)
			num = str(num)
			last_num = num[-1:]
			last_num = int(last_num)
			num = int(num)
			pos = last_num*entries_pos[0]
			try:
				if root != "ms0:/":
					if os.path.isdir(root+"/"+i) == True: info1 = "D  "
					else: info1 = "F  "
					info2 = int(os.path.getsize(root+"/"+i))
				elif root == "ms0:/":
					if os.path.isdir(root+i) == True: info1 = "D  "
					else: info1 = "F  "
					info2 = int(os.path.getsize(root+i))
			except:
				info1 = ""
				info2 = ""
			if len(i) > 20:
				i_len = len(i)-1
				while len(i) > 20:
					i = i[:i_len] + i[(i_len+1):]
					i_len -= 1
				i = str(i) + "..."
			info3 = " Bytes"
			if len(str(info2)) > 4:
				info3 = " KB"
				info2 = info2/1024
			if len(str(info2)) > 4 and info3 == " KB":
				info3 = " MB"
				info2 = info2/1024
			if len(str(info2)) > 4 and info3 == " MB":
				info3 = " GB"
				info2 = info2/1024
			fnt.drawText(img3, offset, pos, info1+str(i))
			fnt.drawText(img3, 350, pos, str(info2)+info3)
		#fnt.drawText(img3, offset2, entries_pos[2]*entries_pos[0], "> ")
		#scr.blit(img3)
		#scr.swap()
		self.update_cursor()

	def update_cursor(self):
		global entries_pos, offset2
		img5.clear(CLEAR_COLOR)
		img5.blit(img3)
		fnt.drawText(img5, offset2, entries_pos[2]*entries_pos[0], "> ")
		scr.blit(img5)
		scr.swap()

	def file_browser(self,entries, root):
		global entries_pos, pos1, the_entries
		pos1 = 0
		entries_pos = [20,0,0]
		img_clear_all()
		the_entries = [entries[i:i+10] for i in range(0, len(entries), 10)]
		self.show_items(the_entries[0],root)
		x3 = True
		while x3 == True:
			if padDown(1):
				if (entries_pos[2]+1) != len(the_entries[pos1]):
					entries_pos[2] += 1
					#self.show_items(the_entries[pos1],root)
					self.update_cursor()
				elif (entries_pos[2]+1) == len(the_entries[pos1]):
					try:
						pos1 += 1
						entries_pos[2] = 0
						self.show_items(the_entries[pos1],root)
					except:
						pos1 = 0
						entries_pos[2] = 0
						self.show_items(the_entries[pos1],root)
			elif padUp(1):
				if entries_pos[2] != len(the_entries[pos1]):
					entries_pos[2] -= 1
					#self.show_items(the_entries[pos1],root)
					self.update_cursor()
				if entries_pos[2] < 0:
					try:
						pos1 -= 1
						entries_pos[2] = len(the_entries[pos1])-1
						self.show_items(the_entries[pos1],root)
					except:
						pos1 = 0
						entries_pos[2] = len(the_entries[len(the_entries)-1])-1
						pos1 -= 1
						self.show_items(the_entries[pos1],root)
						
			elif padCross("r"):
				x3 = False
				browse = the_entries[pos1][entries_pos[2]]
				if os.path.isdir(root+"/"+browse) == True or os.path.isdir(root+browse) == True:
					img_clear_all()
					if root != "ms0:/":
						root, dirs, files = os.walk(root+"/"+browse).next()
					elif root == "ms0:/":
						root, dirs, files = os.walk(root+browse).next()
					browse = dirs+files
					if browse == []: browse = [language[19]]
					entries_pos = [20,0,0]
					self.file_browser(browse, root)
				else:
					if root != "ms0:/" and browse != language[19]:
						if load_file(root+"/"+browse) == False:
							msg(language[22])
							delay()
							img_clear()
							root, dirs, files = os.walk(start_path).next()
							browse = dirs+files
							self.file_browser(browse, root)
						else:
							img_clear()
							root, dirs, files = os.walk(start_path).next()
							browse = dirs+files
							self.file_browser(browse, root)
					elif root == "ms0:/" and browse != language[19]:
						if load_file(root+browse) == False:
							msg(language[22])
							delay()
							img_clear()
							root, dirs, files = os.walk(start_path).next()
							browse = dirs+files
							self.file_browser(browse, root)
						else:
							img_clear()
							root, dirs, files = os.walk(start_path).next()
							browse = dirs+files
							self.file_browser(browse, root)
			elif padCircle("r"):
				x3 = False
				if root != "ms0:/":
					img_clear_all()
					i = len(root)-1
					root = root[:i] + root[(i+1):]
					i -= 1
					while root[i] != "/" and root != "ms0:/":
						root = root[:i] + root[(i+1):]
						i -= 1
					if root != "ms0:/": root = root[:i] + root[(i+1):]
					root, dirs, files = os.walk(root).next()
					browse = dirs+files
					if browse == []: browse = [language[19]]
					entries_pos = [20,0,0]
					self.file_browser(browse, root)
				elif root == "ms0:/":
					img_clear()
			elif padSelect("r"):
				x3 = False
				self.browser_help()
			elif padRT("r"):
				x3 = False
				browse = the_entries[pos1][entries_pos[2]]
				self.file_options(browse, root)
