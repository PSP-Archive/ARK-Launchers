# Check if an ISO/CSO is patched or not
import os, zlib, math

def ceil(num):
	return int(math.ceil(num))
#end of ceil

def is_odd(num):
	odd = num - (math.floor(num / 2.0) * 2)
	if int(odd) == 0:
		return False
	return True
#end of is_odd

def read_size(open_file, read_size = 4):
	#function for getting little endian offset size
	byte_one = ord(open_file.read(1))
	byte_two = ord(open_file.read(1)) * 256
	if read_size == 2:
		return byte_one + byte_two
	byte_three = ord(open_file.read(1)) * 256 * 256
	byte_four = ord(open_file.read(1)) * 256 * 256 * 256
	return byte_one + byte_two + byte_three + byte_four
#End of read_size

def is_patched(source):
	#Check whether or not an ISO/CSO is patched
	#This function will return "UNTOUCHED_ISO_APP\n" or "TOUCHED_ISO_APP\n"
	file = open(source, 'rb')
	cso_magic = file.read(4)
	file.seek(32768)
	iso_magic = file.read(6)
	if cso_magic == "CISO":
		file.seek(16)
		block_size = read_size(file)
		start = (32768 / block_size) * 4 + 24
		file.seek(start)
		first_block_offset = read_size(file)
		first_block_size = read_size(file)
		file.seek(first_block_offset)
		first_block = zlib.decompress(file.read(first_block_size), -15)
		dir_offset = (ord(first_block[140:141]) + (ord(first_block[141:142]) * 256) + (ord(first_block[142:143]) * 256 * 256) + (ord(first_block[143:144]) * 256 * 256 * 256)) * 4 + 24
		file.seek(dir_offset)
		block_offset = read_size(file)
		block_size = read_size(file)
		is_compressed = "yes"
		if block_offset >= 2147483648:
			block_offset = block_offset - 2147483648
			is_compressed = "no"
		if block_size >= 2147483648:
			block_size = block_size - 2147483648
		if is_compressed == "yes":
			file.seek(block_offset)
			dir_block = zlib.decompress(file.read(block_size), -15)
		else:
			file.seek(block_offset)
			dir_block = file.read(block_size)
		pos = 0
		while True:
			if pos >= 2048:
				file.close()
				return "UNTOUCHED_ISO_APP\n"
			next_name_length = ord(dir_block[pos:pos + 1])
			if next_name_length == 0:
				file.close()
				return "UNTOUCHED_ISO_APP\n"
			pos = pos + 2
			next_offset = (ord(dir_block[pos:pos + 1]) + (ord(dir_block[pos + 1:pos + 2]) * 256) + (ord(dir_block[pos + 2:pos + 3]) * 256 * 256) + (ord(dir_block[pos + 3:pos + 4]) * 256 * 256 * 256)) * 4 + 24
			pos = pos + 6
			next_name = dir_block[pos:pos + next_name_length]
			pos = pos + next_name_length
			if is_odd(next_name_length):
				pos = pos + 1
			if next_name == "SYSDIR":
				break
		file.seek(next_offset)
		sysdir_offset = read_size(file)
		is_compressed = "yes"
		if sysdir_offset >= 2147483648:
			is_compressed = "no"
			sysdir_offset = sysdir_offset - 2147483648
		sysdir_size = read_size(file)
		if sysdir_size >= 2147483648:
			sysdir_size = sysdir_size - 2147483648
		file.seek(sysdir_offset)
		if is_compressed == "yes":
			sysdir_block = zlib.decompress(file.read(sysdir_size), -15)
		else:
			sysdir_block = file.read(sysdir_size)
		pos = 0
		while True:
			if pos >= 2048:
				file.close()
				return "UNTOUCHED_ISO_APP\n"
			cur_pos = pos
			dir_record_length = ord(sysdir_block[pos:pos + 1])
			if dir_record_length == 0:
				file.close()
				return "UNTOUCHED_ISO_APP\n"
			pos = pos + 32
			name_length = ord(sysdir_block[pos:pos + 1])
			pos = pos  +1
			name = sysdir_block[pos:pos + name_length]
			if name == "EBOOT.OLD":
				file.close()
				return "TOUCHED_ISO_APP\n"
			pos = cur_pos + dir_record_length
	elif iso_magic == chr(1) + "CD001":
		file.seek(32934)
		block_size = read_size(file)
		file.seek(32908)
		offset = read_size(file) * block_size
		file.seek(offset)
		pos = file.tell()
		while True:
			if file.tell() - pos >= 2048:
				file.close()
				return "UNTOUCHED_ISO_APP\n"
			dir_name_length = ord(file.read(1))
			if dir_name_length == 0:
				file.close()
				return "UNTOUCHED_ISO_APP\n"
			file.seek(file.tell() + 1)
			dir_offset = read_size(file) * block_size
			file.seek(file.tell() + 2)
			dir_name = file.read(dir_name_length)
			if is_odd(dir_name_length):
				file.seek(file.tell() + 1)
			if dir_name == "SYSDIR":
				break
		file.seek(dir_offset)
		pos = file.tell()
		while True:
			if file.tell() - pos >= 2048:
				file.close()
				return "UNTOUCHED_ISO_APP\n"
			cur_pos = file.tell()
			dir_record_size = ord(file.read(1))
			if dir_record_size == 0:
				file.close()
				return "UNTOUCHED_ISO_APP\n"
			file.seek(file.tell() + 31)
			name_length = ord(file.read(1))
			name = file.read(name_length)
			if name == "EBOOT.OLD":
				file.close()
				return "TOUCHED_ISO_APP\n"
			file.seek(cur_pos + dir_record_size)
	else:
		file.close()
		return "UNTOUCHED_ISO_APP\n"
#end of is_patched
