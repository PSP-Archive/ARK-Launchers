#! /bin/bash
# Remove all .pyc files because they are useless and annoying
rm *.pyc
