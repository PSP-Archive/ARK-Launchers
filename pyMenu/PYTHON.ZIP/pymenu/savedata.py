from define import *
from menu import *
from img import *
from common import *
from unzip import *
from icon import *
from controller import *
import os, traceback

def convert(path):
	if os.path.exists(path+"/install.zip") == True:
		msg("Extracting")
		unzipper = unzip()
		the_file = path+"/install.zip"
		unzipper.extract(the_file, "ms0:/PSP/GAME/")
		check_icons()
	else:
		txt(["No INSTALL.ZIP found"])
		save_convert()

def save_convert():
	def check_info():
		path = root+"/"+menu.get()+"/INFO.TXT"
		if os.path.exists(path):
			menu.set_info(open(path, "r").read())
		else: menu.set_info("")
		menu.refresh()
	root, dirs, files = os.walk("ms0:/PSP/SAVEDATA").next()
	if main_menu == "complete": menu = adv_menu()
	elif main_menu == "simple": menu = simple_menu()
	menu.set_clear("icon_save")
	menu.init(dirs)
	#check_info()
	x5 = True
	while x5 == True:
		if padDown(0):
			menu.down()
			#check_info()
		elif padUp(0):
			menu.up()
			#check_info()
		elif padCross("r"):
			x5 = False
			delay()
			convert(root+"/"+menu.get())
		elif padCircle("r"):
			x5 = False
