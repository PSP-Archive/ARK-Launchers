# Simple frontend to pymenu.common.picture
from pymenu.define import *
from pymenu.menu import *
from pymenu.common import *
from pymenu.controller import *
import os

if main_menu == "complete": menu = adv_menu()
elif main_menu == "simple": menu = simple_menu()

def pic_menu():
	if os.path.exists(picture_path) == True:
		root, dirs, files = os.walk(picture_path).next()
		if files == []:
			txt([language[29]])
			x = False
		else:
			menu.set_clear("plain")
			menu.init(files)
			x = True
	else:
		try:
			os.mkdir(picture_path)
			music_menu()
		except:
			x = False
	while x == True:
		if padUp(0): menu.up()
		elif padDown(0): menu.down()
		elif padCross("r"):
			x = False
			image = picture_path+"/"+menu.get()
			picture(image)
			pic_menu()
		elif padCircle("r"): x = False
