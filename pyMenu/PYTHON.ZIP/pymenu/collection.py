#! /usr/bin/env python
import psp2d, os, sys, traceback
from pymenu.define import *
from pymenu.common import *
from pymenu.menu import *
from pymenu.unzip import *
from pymenu.controller import *
sys.path.append("ms0:/pygame/collection")

def init():
	global dirs
	root, dirs, files = os.walk("ms0:/pygame/collection").next()
	if dirs == []:
		if os.path.exists("PYNSTALL.ZIP"):
			msg(language[23])
			unzipper = unzip()
			the_file = "PYNSTALL.ZIP"
			unzipper.extract(the_file, "ms0:/pygame/collection/")
			root, dirs, files = os.walk("ms0:/pygame/collection").next()
		else:
			txt([language[24]])
			return
	for i in dirs:
		try:
			exec "global "+i
			exec "import " + i in globals()
		except:
			print i, "not imported"
			traceback.print_exc()
	main_menu()

def main_menu():
	_menu_ = adv_menu()
	_menu_.set_clear("plain")
	_menu_.init(dirs)
	x = True
	while x == True:
		if padUp(0): _menu_.up()
		elif padDown(0): _menu_.down()
		elif padCircle("r"):
			x = False
		elif padCross("r"):
			x = False
			mod = _menu_.get()
			exec mod + ".main()" in globals()
			main_menu()
