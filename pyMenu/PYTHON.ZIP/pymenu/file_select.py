# File/Folder Selector based on File Browser
from define import *
from img import *
from common import *
from controller import *
import os, shutil

return_value = None

def goto(entries, root):
	browser_menu().file_browser(entries, root)

def get():
	return return_value

class browser_menu:
	global entries, clipboard, entries_pos

	def show_items(self,entry,root):
		img_clear_all()
		offset = 150
		offset2 = 110
		fnt.drawText(img3, 10, 250, root)
		for i in entry:
			num = entry.index(i)
			num = str(num)
			last_num = num[-1:]
			last_num = int(last_num)
			num = int(num)
			pos = last_num*entries_pos[0]
			try:
				if root != "ms0:/":
					if os.path.isdir(root+"/"+i) == True: info1 = "D  "
					else: info1 = "F  "
					info2 = int(os.path.getsize(root+"/"+i))
				elif root == "ms0:/":
					if os.path.isdir(root+i) == True: info1 = "D  "
					else: info1 = "F  "
					info2 = int(os.path.getsize(root+i))
			except:
				info1 = ""
				info2 = ""
			fnt.drawText(img3, offset, pos, info1+str(i))
			fnt.drawText(img3, 350, pos, str(info2)+"KB")
		fnt.drawText(img3, offset2, entries_pos[2]*entries_pos[0], "> ")
		scr.blit(img3)
		scr.swap()

	def file_browser(self,entries, root):
		global entries_pos, pos1, the_entries, return_value
		pos1 = 0
		entries_pos = [20,0,0]
		img_clear_all()
		the_entries = [entries[i:i+10] for i in range(0, len(entries), 10)]
		self.show_items(the_entries[0],root)
		x3 = True
		while x3 == True:
			if padDown(2):
				if (entries_pos[2]+1) != len(the_entries[pos1]):
					entries_pos[2] += 1
					self.show_items(the_entries[pos1],root)
				elif (entries_pos[2]+1) == len(the_entries[pos1]):
					try:
						pos1 += 1
						entries_pos[2] = 0
						self.show_items(the_entries[pos1],root)
					except:
						pos1 = 0
						entries_pos[2] = 0
						self.show_items(the_entries[pos1],root)
			elif padUp(2):
				if entries_pos[2] != len(the_entries[pos1]):
					entries_pos[2] -= 1
					self.show_items(the_entries[pos1],root)
				if entries_pos[2] < 0:
					try:
						pos1 -= 1
						entries_pos[2] = len(the_entries[pos1])-1
						self.show_items(the_entries[pos1],root)
					except:
						pos1 = 0
						entries_pos[2] = len(the_entries[len(the_entries)-1])-1
						pos1 -= 1
						self.show_items(the_entries[pos1],root)
						
			elif padCross("r"):
				x3 = False
				browse = the_entries[pos1][entries_pos[2]]
				if os.path.isdir(root+"/"+browse) == True or os.path.isdir(root+browse) == True:
					img_clear_all()
					if root != "ms0:/":
						root, dirs, files = os.walk(root+"/"+browse).next()
					elif root == "ms0:/":
						root, dirs, files = os.walk(root+browse).next()
					browse = dirs+files
					if browse == []: browse = [language[19]]
					entries_pos = [20,0,0]
					goto(browse, root)
				else:
					if root != "ms0:/" and browse != language[19]:
						return_value = root+"/"+browse
					elif root == "ms0:/" and browse != language[19]:
						return_value = root+browse
			elif padCircle("r"):
				x3 = False
				if root != "ms0:/":
					img_clear_all()
					i = len(root)-1
					root = root[:i] + root[(i+1):]
					i -= 1
					while root[i] != "/" and root != "ms0:/":
						root = root[:i] + root[(i+1):]
						i -= 1
					if root != "ms0:/": root = root[:i] + root[(i+1):]
					root, dirs, files = os.walk(root).next()
					browse = dirs+files
					if browse == []: browse = [language[19]]
					entries_pos = [20,0,0]
					goto(browse, root)
				elif root == "ms0:/":
					img_clear()
					return_value = "cancel"
			elif padStart("r"):
					if root != "ms0:/":
						return_value = root+"/"+browse
					elif root == "ms0:/":
						return_value = "ms0:/"
