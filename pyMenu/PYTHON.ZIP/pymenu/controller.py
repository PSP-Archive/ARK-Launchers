# Controller module, by qwikrazor87
# "h" is the default argument,
# it will return true whenever the buttons are held or pressed by default,
# so calling padDown("h") is the same as padDown().
# The expected arguments are
# "p" - pressed
# "h" - held
# "r" - released
# integer - intervals, returns true when the integer reaches zero.

# The functions to call are
# padUp(), padDown(), padLeft(), padRight(),
# padCross(), padCircle(), padSquare(), padTriangle(),
# padStart(), padSelect(), padLT(), and padRT()

import psp2d

pU=False
nU=0
pD=False
nD=0
pL=False
nL=0
pR=False
nR=0
pX=False
nX=0
pO=False
nO=0
pS=False
nS=0
pT=False
nT=0
pST=False
nST=0
pSL=False
nSL=0
pLT=False
nLT=0
pRT=False
nRT=0

def padUp(option="h"):
	pad = psp2d.Controller()
	global pU, nU
	if option == "p":
		if pad.up:
			if pU == False:
				pU = True
				return True
		else:
			if pU == True:
				pU = False
	elif option == "r":
		if pad.up:
			pU = True
		else:
			if pU == True:
				pU = False
				return True
	elif option == "h":
		if pad.up:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.up:
			if nU == 0:
				nU = option
				return True
			elif nU > 0:
				nU = nU - 1
		else:
			if nU > 0:
				nU = 0

def padDown(option="h"):
	pad = psp2d.Controller()
	global pD, nD
	if option == "p":
		if pad.down:
			if pD == False:
				pD = True
				return True
		else:
			if pD == True:
				pD = False
	elif option == "r":
		if pad.down:
			pD = True
		else:
			if pD == True:
				pD = False
				return True
	elif option == "h":
		if pad.down:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.down:
			if nD == 0:
				nD = option
				return True
			elif nD > 0:
				nD = nD - 1
		else:
			if nD > 0:
				nD = 0

def padLeft(option="h"):
	pad = psp2d.Controller()
	global pL, nL
	if option == "p":
		if pad.left:
			if pL == False:
				pL = True
				return True
		else:
			if pL == True:
				pL = False
	elif option == "r":
		if pad.left:
			pL = True
		else:
			if pL == True:
				pL = False
				return True
	elif option == "h":
		if pad.left:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.left:
			if nL == 0:
				nL = option
				return True
			elif nL > 0:
				nL = nL - 1
		else:
			if nL > 0:
				nL = 0

def padRight(option="h"):
	pad = psp2d.Controller()
	global pR, nR
	if option == "p":
		if pad.right:
			if pR == False:
				pR = True
				return True
		else:
			if pR == True:
				pR = False
	elif option == "r":
		if pad.right:
			pR = True
		else:
			if pR == True:
				pR = False
				return True
	elif option == "":
		if pad.right:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.right:
			if nR == 0:
				nR = option
				return True
			elif nR > 0:
				nR = nR - 1
		else:
			if nR > 0:
				nR = 0

def padCross(option="h"):
	pad = psp2d.Controller()
	global pX, nX
	if option == "p":
		if pad.cross:
			if pX == False:
				pX = True
				return True
		else:
			if pX == True:
				pX = False
	elif option == "r":
		if pad.cross:
			pX = True
		else:
			if pX == True:
				pX = False
				return True
	elif option == "h":
		if pad.cross:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.cross:
			if nX == 0:
				nX = option
				return True
			elif nX > 0:
				nX = nX - 1
		else:
			if nX > 0:
				nX = 0

def padCircle(option="h"):
	pad = psp2d.Controller()
	global pO, nO
	if option == "p":
		if pad.circle:
			if pO == False:
				pO = True
				return True
		else:
			if pO == True:
				pO = False
	elif option == "r":
		if pad.circle:
			pO = True
		else:
			if pO == True:
				pO = False
				return True
	elif option == "h":
		if pad.circle:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.circle:
			if nO == 0:
				nO = option
				return True
			elif nO > 0:
				nO = nO - 1
		else:
			if nO > 0:
				nO = 0

def padSquare(option="h"):
	pad = psp2d.Controller()
	global pS, nS
	if option == "p":
		if pad.square:
			if pS == False:
				pS = True
				return True
		else:
			if pS == True:
				pS = False
	elif option == "r":
		if pad.square:
			pS = True
		else:
			if pS == True:
				pS = False
				return True
	elif option == "h":
		if pad.square:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.square:
			if nS == 0:
				nS = option
				return True
			elif nS > 0:
				nS = nS - 1
		else:
			if nS > 0:
				nS = 0

def padTriangle(option="h"):
	pad = psp2d.Controller()
	global pT, nT
	if option == "p":
		if pad.triangle:
			if pT == False:
				pT = True
				return True
		else:
			if pT == True:
				pT = False
	elif option == "r":
		if pad.triangle:
			pT = True
		else:
			if pT == True:
				pT = False
				return True
	elif option == "h":
		if pad.triangle:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.triangle:
			if nT == 0:
				nT = option
				return True
			elif nT > 0:
				nT = nT - 1
		else:
			if nT > 0:
				nT = 0

def padStart(option="h"):
	pad = psp2d.Controller()
	global pST, nST
	if option == "p":
		if pad.start:
			if pST == False:
				pST = True
				return True
		else:
			if pST == True:
				pST = False
	elif option == "r":
		if pad.start:
			pST = True
		else:
			if pST == True:
				pST = False
				return True
	elif option == "h":
		if pad.start:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.start:
			if nST == 0:
				nST = option
				return True
			elif nST > 0:
				nST = nST - 1
		else:
			if nST > 0:
				nST = 0

def padSelect(option="h"):
	pad = psp2d.Controller()
	global pSL, nSL
	if option == "p":
		if pad.select:
			if pSL == False:
				pSL = True
				return True
		else:
			if pSL == True:
				pSL = False
	elif option == "r":
		if pad.select:
			pSL = True
		else:
			if pSL == True:
				pSL = False
				return True
	elif option == "h":
		if pad.select:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.select:
			if nSL == 0:
				nSL = option
				return True
			elif nSL > 0:
				nSL = nSL - 1
		else:
			if nSL > 0:
				nSL = 0

def padLT(option="h"):
	pad = psp2d.Controller()
	global pLT, nLT
	if option == "p":
		if pad.l:
			if pLT == False:
				pLT = True
				return True
		else:
			if pLT == True:
				pLT = False
	elif option == "r":
		if pad.l:
			pLT = True
		else:
			if pLT == True:
				pLT = False
				return True
	elif option == "h":
		if pad.l:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.l:
			if nLT == 0:
				nLT = option
				return True
			elif nLT > 0:
				nLT = nLT - 1
		else:
			if nLT > 0:
				nLT = 0

def padRT(option="h"):
	pad = psp2d.Controller()
	global pRT, nRT
	if option == "p":
		if pad.r:
			if pRT == False:
				pRT = True
				return True
		else:
			if pRT == True:
				pRT = False
	elif option == "r":
		if pad.r:
			pRT = True
		else:
			if pRT == True:
				pRT = False
				return True
	elif option == "h":
		if pad.r:
			return True
	elif str(type(option)) == "<type 'int'>":
		if pad.r:
			if nRT == 0:
				nRT = option
				return True
			elif nRT > 0:
				nRT = nRT - 1
		else:
			if nRT > 0:
				nRT = 0
#End of controller
