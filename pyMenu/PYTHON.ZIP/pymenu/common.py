from define import *
from img import *
from controller import *
import time, math, os, traceback, re
try:
	psp_mods = True

	# MP3 Playback
	if music_player == "mp3":
		import pspmp3
		pspmp3.init(1)

	# OGG Playback, disabled
	elif music_player == "ogg":
		import pspogg
		pspogg.init(2)

	# WAV Playback, disabled
	elif music_player == "wav":
		import pspsnd
		psp_mods = False
except:
	# PC WAV/MP3/OGG Playback
	import pspsnd
	psp_mods = False

def get_eboot_type(path):
	"Return the type of eboot (homebrew, pops or psn)"
	# By qwikrazor87, using eboot offsets
	eboot = open(path,"rb")
	eboot.seek(40)
	paramheader = eboot.read(4)
	if paramheader == chr(0) + "PSF":
		eboot.seek(48)
		labelstart = ord(eboot.read(1)) + ord(eboot.read(1)) * 256 + ord(eboot.read(1)) * 256 * 256 + ord(eboot.read(1)) * 256  * 256 * 256
		valuestart = ord(eboot.read(1)) + ord(eboot.read(1)) * 256 + ord(eboot.read(1)) * 256 * 256 + ord(eboot.read(1)) * 256  * 256 * 256
		entries = ord(eboot.read(1)) + ord(eboot.read(1)) * 256 + ord(eboot.read(1)) * 256 * 256 + ord(eboot.read(1)) * 256  * 256 * 256
		while entries > 0:
			entries = entries - 1
			cur = eboot.tell()
			labelnameoffset = ord(eboot.read(1)) + ord(eboot.read(1)) * 256
			eboot.seek(labelnameoffset + labelstart + 40)
			labelname = eboot.read(8)
			if labelname == "CATEGORY":
				eboot.seek(cur + 12)
				valueoffset = ord(eboot.read(1)) + ord(eboot.read(1)) * 256 + ord(eboot.read(1)) * 256 * 256 + ord(eboot.read(1)) * 256  * 256 * 256
				eboot.seek(valueoffset + valuestart + 40)
				categorytype = eboot.read(2)
				if categorytype == "MG":
					return "HOMEBREW_APP\n"
				elif categorytype == "ME":
					return "POPS_APP\n"
				elif categorytype == "EG":
					return "PSN_APP\n"
				else:
					return "HOMEBREW_APP\n"
			eboot.seek(cur + 16)
	else:
		return "HOMEBREW_APP\n"

def get_eboot_type_two(path):
	"Return the type of eboot (homebrew, pops or psn)"
	# By Acid_Snake, using regex
	eboot_file = open(path, "r").read(500).encode("hex") # read the first 500 bytes, enough to do the checking
	r = re.compile("004d4700") # MG (Homebrew App)
	m = r.search(eboot_file)
	if m != None:
		return "HOMEBREW_APP\n"
	else:
		r = re.compile("004d4500") # ME (POPS App)
		m = r.search(eboot_file)
		if m != None:
			return "POPS_APP\n"
		else:
			r = re.compile("00454700") # EG (PSN App)
			m = r.search(eboot_file)
			if m != None:
				return "PSN_APP\n"
			else:
				return "HOMEBREW_APP\n" # default

def show_loading():
	# Show the splashscreen
	alt_load = psp2d.Image(480, 272)
	alt_load.clear(CLEAR_COLOR)
	def load():
		if use_splash == True:
			fnt2.drawText(load_img, 270, 50, "WOLOLO.NET")
			scr2.blit(load_img)
		elif use_splash == False:
			fnt2.drawText(alt_load, 270, 50, "WOLOLO.NET")
			scr2.blit(alt_load)
		scr2.swap()
	if use_splash == True or use_splash == False:
		load()
		delay()
	else:
		if type(use_splash) == type([]):
			splash(use_splash[0] if use_splash[0] != "" else input, use_splash[1] if use_splash[1] != "" else input)

def splash(image=input, text=input):
	# Customizable splashscreen
	load_img = psp2d.Image(image) if image != input else psp2d.Image(480, 272)
	if image == input: load_img.clear(CLEAR_COLOR)
	def load():
		fnt2.drawText(load_img, 0, 0, "loading..." if text == input else text)
		scr2.blit(load_img)
		scr2.swap()
	load()
	delay()

def picture(image):
	# Picture Viewer
	load_img = psp2d.Image(image)
	scr2.blit(load_img)
	scr2.swap()
	x = True
	while x == True:
		if padCircle("r"): x = False

def music(sound):
	# Music Player with mp3 and ogg support
	# Cannot have MP3, OGG and WAV together, only one of them (MP3 is default)
	name, ext = os.path.splitext(sound)
	cwd = os.getcwd()
	fnt3.drawText(img3, 0, 200, "Playing: "+os.path.basename(name))
	scr.blit(img3)
	scr.swap()
	os.chdir("ms0:/MUSIC")
	sound = os.path.basename(sound)

	if psp_mods == False:
		#reload(pspsnd)
		pspsnd.Music(sound)
		pspsnd.Music(sound).start()
		x = True
		while x == True:
			if padCircle("r"):
				pspsnd.Music(sound).stop()
				x = False
	elif psp_mods == True:
		if ext == ".mp3" or ext == ".MP3" and music_player == "mp3":
			pspmp3.load(sound)
			pspmp3.play()
			x = True
			while x == True:
				if pspmp3.endofstream() == 1 or padCircle("r"):
					pspmp3.stop()
					x = False
				elif padCross("r"):
					pspmp3.pause()
				else: pass
		elif ext == ".ogg" or ext == ".OGG" and music_player == "ogg":
			pspogg.load(sound)
			pspogg.play()
			x = True
			while x == True:
				if pspogg.endofstream() == 1 or padCircle("r"):
					pspogg.stop()
					x = False
				elif padCross("r"):
					pspogg.pause()
				else: pass
		elif ext == ".wav" or ext == ".WAV" and music_player == ".wav":
			pspsnd.Music(sound)
			pspsnd.Music(sound).start()
			x = True
			while x == True:
				if padCircle("r"):
					pspsnd.Music(sound).stop()
					x = False
		else: pass
	os.chdir(cwd)


def sound(tone="button50.mp3"):
	if psp_mods == True:
		pspmp3.load(tone)
		pspmp3.play()
		while pspmp3.endofstream() != 1: pass
	else:
		pass


def msg(input):
	# Show a message to the user
	img3.clear(CLEAR_COLOR)
	fnt.drawText(img3, 0, 30, input)
	scr.blit(img3)
	scr.swap()
	delay()

def delay():
	# time.sleep alternative
	time_lapse = 0.15
	time_start = time.time()
	time_end = (time_start + time_lapse)
	while time_end > time.time():
		pass

def txt(text):
	# Print-like function with up to 15 lines
	dummy = [1]
	if type(text) != type(dummy):
		return "Not a List"
	elif len(text) > 15:
		return "The list has more than 15 lines"
	else:
		img3.clear(CLEAR_COLOR)
		for i in text:
			index = text.index(i)
			fnt.drawText(img3, 0, index*15, i)
		fnt.drawText(img3, 0, 225, "Press Circle to exit")
		scr.blit(img3)
		scr.swap()
		x = True
		while x == True:
			if padCircle("r"):
				x = False

def help():
	# Common help menu
	img_clear()
	fnt.drawText(img3, 0, 0, "Up/Down to scroll")
	fnt.drawText(img3, 0, 30, "Cross to select")
	fnt.drawText(img3, 0, 60, "Circle to boot the last played game")
	fnt.drawText(img3, 0, 90, "Square to change menu style")
	fnt.drawText(img3, 0, 150, "pyMenu version: 0.3")
	scr.blit(img3)
	scr.swap()
	x10 = True
	while x10 == True:
		if padSelect("r"):
			x10 = False
