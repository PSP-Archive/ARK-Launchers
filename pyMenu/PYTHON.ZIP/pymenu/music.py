# Simple frontend to pymenu.common.music
from pymenu.define import *
from pymenu.menu import *
from pymenu.common import *
from pymenu.controller import *
import os

menu = adv_menu()

def music_menu():
	if os.path.exists(music_path) == True:
		root, dirs, files = os.walk(music_path).next()
		if files == []:
			txt([language[29]])
			x = False
		else:
			menu.set_clear("plain")
			menu.init(files)
			x = True
	else:
		try:
			os.mkdir(music_path)
			music_menu()
		except:
			x = False
	while x == True:
		if padUp(0): menu.up()
		elif padDown(0): menu.down()
		elif padCross("r"):
			x = False
			sound = music_path+"/"+menu.get()
			music(sound)
			music_menu()
		elif padCircle("r"): x = False
