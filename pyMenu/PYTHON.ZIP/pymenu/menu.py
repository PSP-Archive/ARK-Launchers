# Different menu styles used by pyMenu
# It can be ported to any other homebrew fairly easy
# by Acid_Snake
from define import *
from img import *
import common
from controller import *
clear = 0
pos1 = 0
extra_info = ""

class adv_menu:
	"""A more advanced menu showing up to 10 items at a time.
Usage:
adv_menu().init(list)
where list is the list of items to be shown"""

	def add_entry(self,entry):
		"Add an entry to the current list"
		global entries
		entries = entries.__add__(entry)
		self.show_items(entries)

	def set_clear(self, clear_):
		"Set to either clear the entire screen or keep pymenu's background"
		global clear
		if clear_ == "plain": clear = 0
		elif clear_ == "icon_game": clear = 1
		elif clear_ == "icon_iso": clear = 2
		elif clear_ == "icon_save": clear = 3

	def get(self):
		"Return the currently selected item"
		return the_entries[pos1][entries_pos[2]]

	def show_items(self,entry):
		"Draw the main screen with the selected item"
		global offset2
		img_clear()
		offset = 30
		offset2 = 20
		for i in entry:
			num = entry.index(i)
			num = str(num)
			last_num = num[-1:]
			last_num = int(last_num)
			num = int(num)
			pos = last_num*entries_pos[0]
			fnt.drawText(img3, offset, pos, str(i))
		self.update_cursor()

	def update_cursor(self):
		global offset2, entries_pos, extra_info
		img5.clear(CLEAR_COLOR)
		img5.blit(img3)
		if clear == 1: img_clear_game_adv("ms0:/PSP/GAME/"+self.get()+"/icon0.png")
		elif clear == 2: img_clear_game_adv("ms0:/pygame/tmp/"+self.get()+".png")
		elif clear == 3: img_clear_game_adv("ms0:/PSP/SAVEDATA/"+self.get()+"/icon0.png")
		fnt.drawText(img5, offset2, entries_pos[2]*entries_pos[0], "> ")
		fnt.drawText(img5, 150, 200, extra_info)
		scr.blit(img5)
		scr.swap()


	def init(self, entries, info = ""):
		"Initialize the menu into it's default state"
		global entries_pos, the_entries, pos1, extra_info
		extra_info = info
		pos1 = 0
		entries_pos = [20,0,0]
		img_clear()
		the_entries = [entries[i:i+10] for i in range(0, len(entries), 10)]
		adv_menu().show_items(the_entries[0])

	def move_down(self):
		"Move selection down"
		global pos1
		if (entries_pos[2]+1) != len(the_entries[pos1]):
			entries_pos[2] += 1
			#self.show_items(the_entries[pos1])
			self.update_cursor()
		elif (entries_pos[2]+1) == len(the_entries[pos1]):
			try:
				pos1 += 1
				entries_pos[2] = 0
				self.show_items(the_entries[pos1])
			except:
				pos1 = 0
				entries_pos[2] = 0
				self.show_items(the_entries[pos1])

	def move_up(self):
		"Move selection up"
		global pos1
		if entries_pos[2] != len(the_entries[pos1]):
			entries_pos[2] -= 1
			#self.show_items(the_entries[pos1])
			self.update_cursor()
		if entries_pos[2] < 0:
			try:
				pos1 -= 1
				entries_pos[2] = len(the_entries[pos1])-1
				self.show_items(the_entries[pos1])
			except:
				pos1 = 0
				entries_pos[2] = len(the_entries[len(the_entries)-1])-1
				pos1 -= 1
				self.show_items(the_entries[pos1])

	def up(self):
		common.sound()
		self.move_up()

	def down(self):
		common.sound()
		self.move_down()

	def refresh(self):
		"Refresh the menu without changing the state of the entries"
		self.show_items(the_entries[pos1])

	def set_info(self, info):
		global extra_info
		extra_info = info


class simple_menu:
	"""A simple menu showing one item at a time.
Usage:
simple_menu().init(list)
where list is the list of items to be shown"""

	def set_clear(self, clear_):
		"Set to either clear the entire screen or keep pymenu's background"
		global clear
		if clear_ == "plain": clear = 0
		elif clear_ == "icon_game": clear = 1
		elif clear_ == "icon_iso": clear = 2
		elif clear_ == "icon_save": clear = 3

	def show_text(self, dirs):
		"Draw the main screen with the selected item"
		if clear == 0: img_clear()
		elif clear == 1: img_clear_game("ms0:/PSP/GAME/"+self.get()+"/icon0.png")
		elif clear == 2: img_clear_game("ms0:/pygame/tmp/"+self.get()+".png")
		elif clear == 3: img_clear_game("ms0:/PSP/SAVEDATA/"+self.get()+"/icon0.png")
		img3.blit(img)
		fnt.drawText(img3, 0, 0, "Press Select for help")
		fnt.drawText(img3, 0, 90, dirs[pos1])
		scr.blit(img3)
		scr.swap()

	def get(self):
		"Return the currently selected item"
		return dirs[pos1]

	def init(self, dirs_):
		"Initialize the menu into it's default state"
		global pos1, dirs
		pos1 = 0
		dirs = dirs_
		self.show_text(dirs_)

	def up(self):
		"Move selection up"
		global pos1
		padUp(2)
		try:
			pos1 -= 1
			self.show_text(dirs)
		except:
			pos1 = len(dirs)-1
			self.show_text(dirs)

	def down(self):
		"Move selection down"
		global pos1
		padDown(2)
		try:
			pos1 += 1
			self.show_text(dirs)
		except:
			pos1 = 0
			self.show_text(dirs)
