from define import *
from menu import *
from img import *
from common import *
from controller import *
import os, shutil, config
runlevel = "auto" # possible options are: homebrew, pops, psn or auto

def run_eboot(path):
	file1 = open("ms0:/path.txt","w")
	file2 = open("ms0:/mode.txt","w")
	for i in eboot_names:
		if os.path.exists(path+"/"+i) == True:
			file1.write(path+"/"+i+"\n")
			file1.close()
			if runlevel == "homebrew": file2.write("HOMEBREW_APP\n")
			elif runlevel == "psn": file2.write("PSN_APP\n")
			elif runlevel == "pops": file2.write("POPS_APP\n")
			elif runlevel == "auto": file2.write(get_eboot_type(path+"/"+i))
			file2.close()
			msg(language[20])
			raise SystemExit
	msg(language[26])

def delete(path):
	img_clear()
	img3.clear(CLEAR_COLOR)
	fnt.drawText(img3, 0, 0, language[27])
	fnt.drawText(img3, 0, 30, language[28])
	scr.blit(img3)
	scr.swap()
	x6 = True
	while x6 == True:
		if padCross("r"):
			x6 = False
			game_select()
		elif padStart("r"):
			x6 = False
			shutil.rmtree(path)

def game_select():
	global runlevel
	root, dirs, files = os.walk("ms0:/PSP/GAME").next()
	for i in dirs:
		if i.startswith("__sce__") or i.startswith("_sce_"):
			dirs.remove(i)
	for i in dirs:
		if i.startswith("__SCE__") or i.startswith("_SCE_"):
			dirs.remove(i)
	if main_menu == "complete": menu = adv_menu()
	elif main_menu == "simple": menu = simple_menu()
	if game_menu == "icon": menu.set_clear("icon_game")
	elif game_menu == "plain": menu.set_clear("plain")
	menu.init(dirs)
	menu.set_info("Runlevel: "+runlevel)
	menu.refresh()
	x7 = True
	while x7 == True:
		if padDown(0):
			menu.down()
		elif padUp(0):
			menu.up()
		elif padLeft(2):
			if runlevel == "homebrew": runlevel = "pops"
			elif runlevel == "pops": runlevel = "psn"
			elif runlevel == "psn": runlevel = "auto"
			elif runlevel == "auto": runlevel = "homebrew"
			menu.set_info("Runlevel: "+runlevel)
			menu.refresh()
		elif padRight(2):
			if runlevel == "auto": runlevel = "psn"
			elif runlevel == "psn": runlevel = "pops"
			elif runlevel == "pops": runlevel = "homebrew"
			elif runlevel == "homebrew": runlevel = "auto"
			menu.set_info("Runlevel: "+runlevel)
			menu.refresh()
		elif padCross("r"):
			x7 = False
			run_eboot(root+"/"+menu.get())
		elif padCircle("r"):
			x7 = False
		elif padTriangle("r"):
			x7 = False
			delete(root+"/"+menu.get())
			game_select()
