from define import *
from common import *
from menu import *

def text_reader(path):
	# Very simple text reader
	lines = open(path, "r").readlines()
	if lines == []: return False
	menu = adv_menu()
	menu.init(lines)
	x = True
	while x == True:
		if padUp(0): menu.up()
		elif padDown(0): menu.down()
		elif padCircle("r"): x = False
