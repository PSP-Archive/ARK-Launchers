# Unziper used by pyMenu since python 2.5 does not have zipfile.ExtractAll()
# I can't remember the original author/s, these are my mods:
# - eboot.pbp is detected and renamed to wmenu.bin
# - Changed the way directories were recreated
from define import *
import zipfile, os, zlib, struct

class unzip:
	# Used by save_convert()
	def __init__(self, verbose = False, percent = 10):
		self.verbose = verbose
		self.percent = percent
	def extract(self, file_, dir_):
		#if not dir.endswith(':') and not os.path.exists(dir):
		#	os.mkdir(dir)
		zf = zipfile.ZipFile(file_)
		self._createstructure(file_, dir_)
		num_files = len(zf.namelist())
		percent = self.percent
		divisions = 100 / percent
		perc = int(num_files / divisions)
		for i, name in enumerate(zf.namelist()):
			if os.path.basename(name) == "EBOOT.PBP" or os.path.basename(name) == "eboot.pbp":
				extract_from_zip(name, os.path.join(dir_, os.path.dirname(name)+"/"+"wmenu.bin"), zipfile.ZipFile(file_))
			elif not name.endswith('/'):
				extract_from_zip(name, os.path.join(dir_, name), zipfile.ZipFile(file_))
	def _createstructure(self, file_, dir_):
		self._listdirs(file_, dir_)
	def _makedirs(self, name, basedir):
		if os.path.exists(os.path.dirname(basedir+name)) == False:
			self._makedirs(os.path.dirname(name), basedir)
		if os.path.exists(basedir+name) == False: os.mkdir(basedir+name)
	def _listdirs(self, file_, dir_):
		zf = zipfile.ZipFile(file_)
		for name in zf.namelist():
			if name.endswith("/") == False: self._makedirs(os.path.dirname(name), dir_) # it's a file
			elif name.endswith("/") == True: self._makedirs(name, dir_) # it's a directory

def extract_from_zip(name, dest_path, zip_file):
    """Python 2.5 version :("""
    dest_file = open(dest_path, 'wb')
    info = zip_file.getinfo(name)
    if info.compress_type == zipfile.ZIP_STORED:
        decoder = None
    elif info.compress_type == zipfile.ZIP_DEFLATED:
        decoder = zlib.decompressobj(-zlib.MAX_WBITS)
    else:
        raise zipfile.BadZipFile("Unrecognized compression method")

    # Seek over the fixed size fields to the "file name length" field in
    # the file header (26 bytes). Unpack this and the "extra field length"
    # field ourselves as info.extra doesn't seem to be the correct length.
    zip_file.fp.seek(info.header_offset + 26)
    file_name_len, extra_len = struct.unpack("<HH", zip_file.fp.read(4))
    zip_file.fp.seek(info.header_offset + 30 + file_name_len + extra_len)

    bytes_to_read = info.compress_size

    while True:
        buff = zip_file.fp.read(min(bytes_to_read, 102400))
        if not buff:
            break
        bytes_to_read -= len(buff)
        if decoder:
            buff = decoder.decompress(buff)
        dest_file.write(buff)

    if decoder:
        dest_file.write(decoder.decompress('Z'))
        dest_file.write(decoder.flush())
