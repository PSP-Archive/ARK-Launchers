#! /usr/bin/env python
#-*- coding: UTF-8 -*-
# Plugin manager for PS Vita
# by Acid_Snake
import re, os, psp2d, sys
from pymenu.define import *
from pymenu.common import *
from pymenu.menu import *
from pymenu.controller import *
from pymenu import file_select

path = False
mode = None
headers = ["7f454c46", "7e505350"]
def_options = [language[30], language[31], language[32]]
part1 = "(.*?),"
part2 = ",(.*?),"
part3 = "(on|off)"
part4 = "(umdemu|game|pops)"
part5 = "ms0:/(.*?).prx"
part6 = " 1| 0"

def init():
	global plugins, path, mode
	root, dirs, files = os.walk("ms0:/PSP/SAVEDATA").next()
	if version == "PRO":
		path = os.getcwd()+"/"
		mode = "ARK"
	elif version == "CEF":
		path = os.getcwd()+"/"
		mode = "CEF"
	if path == False:
		txt([language[33]+" ms0:/PSP/SAVEDATA"])
		return

	if mode == "ARK":
		if os.path.exists(path+"/plugins.txt") == False:
			open(path+"/plugins.txt","w").close()
		plugins_file = open(path+"/plugins.txt","r")
	elif mode == "CEF":
		if os.path.exists(path+"/game.txt") == False:
			open(path+"/game.txt","w").close()
		plugins_file = open(path+"/game.txt","r")
	plugins = plugins_file.readlines()
	plugins_file.close()
	root, dirs, files = None, None, None
	main()

def write():
	global plugins
	if mode == "ARK":
		plugins_file = open(path+"/plugins.txt", "w")
		plugins_file.close()
		plugins_file = open(path+"/plugins.txt", "a+")
	elif mode == "CEF":
		plugins_file = open(path+"/game.txt", "w")
		plugins_file.close()
		plugins_file = open(path+"/game.txt", "a+")
	for plugin in plugins:
		plugins_file.write(plugin)
	plugins_file.close()

def to_game(plugin):
	global plugins
	r = re.compile(part1)
	m = r.search(plugin)
	part = m.group()
	new = plugin.replace(part, "game,")
	if new in plugins:
		check(new)
	else:
		plugins[plugins.index(plugin)] = new

def to_pops(plugin):
	global plugins
	r = re.compile(part1)
	m = r.search(plugin)
	part = m.group()
	new = plugin.replace(part, "pops,")
	if new in plugins:
		check(new)
	else:
		plugins[plugins.index(plugin)] = new

def to_umdemu(plugin):
	global plugins
	r = re.compile(part1)
	m = r.search(plugin)
	part = m.group()
	new = plugin.replace(part, "umdemu,")
	if new in plugins:
		check(new)
	else:
		plugins[plugins.index(plugin)] = new

def change_mode(plugin):
	global plugins
	if mode == "ARK":
		r = re.compile(part3)
		m = r.search(plugin)
		part = m.group()
		if part == "on":
			plugins[plugins.index(plugin)] = plugin.replace(part+"\n", "off\n")
		elif part == "off":
			plugins[plugins.index(plugin)] = plugin.replace(part+"\n", "on\n")
	elif mode == "CEF":
		r = re.compile(part6)
		m = r.search(plugin)
		part = m.group()
		if part == " 1":
			plugins[plugins.index(plugin)] = plugin.replace(part, " 0")
		elif part == " 0":
			plugins[plugins.index(plugin)] = plugin.replace(part, " 1")

def delete(plugin):
	global plugins
	r = re.compile(part5)
	m = r.search(plugin)
	part = m.group()
	if os.path.exists(part) == True: os.remove(part)
	else: pass
	plugins.remove(plugin)

def remove(plugin):
	global plugins
	r = re.compile(part5)
	m = r.search(plugin)
	part = m.group()
	plugins.remove(plugin)

def duplicate(plugin):
	global plugins
	check(plugin)
	if plugin in plugins: pass
	else:
		plugin = [plugin]
		plugins = plugins+plugin

def check(plugin):
	r = re.compile(part1)
	m = r.search(plugin)
	part = m.group()
	r2 = re.compile(part4)
	m2 = r2.search(part)
	part2 = m2.group()
	if part2 == "umdemu":
		to_game(plugin)
	elif part2 == "game":
		to_pops(plugin)
	elif part2 == "pops":
		to_umdemu(plugin)
	return plugin

def goto_browser():
	root, dirs, files = os.walk(start_path).next()
	browse = dirs+files
	file_select.browser_menu().file_browser(browse, root)

def main():
	global plugins
	options = plugins+def_options
	if main_menu == "complete": menu = adv_menu()
	elif main_menu == "simple": menu = simple_menu()
	menu.set_clear("plain")
	menu.init(options)
	x = True
	while x == True:
		if padUp(0): menu.up()
		elif padDown(0): menu.down()
		elif padCross("r"):
			x = False
			if menu.get() == language[31]:
				write()
				return
			elif menu.get() == language[32]:
				return
			elif menu.get() == language[30]:
				root, dirs, files = os.walk(start_path).next()
				browse = dirs+files
				file_select.browser_menu().file_browser(browse, root)
				new_plugin = file_select.get()
				if new_plugin == None or new_plugin == "cancel":
					main()
				elif open(new_plugin,"r").read(4).encode("hex") not in headers:
					txt([language[34]])
					main()
				elif new_plugin == "cancel":
					main()
				else:
					if mode == "ARK":
						if "umdemu, " + new_plugin + ", on\n" not in plugins:
							plugins = plugins + ["umdemu, " + new_plugin + ", on\n"]
					elif mode == "CEF":
						if new_plugin + " 1" not in plugins:
							plugins = plugins + [new_plugin + " 1"]
					else: print  mode
					main()
			else:
				change_mode(menu.get())
				main()
		elif padSquare("r"):
			x = False
			if menu.get() == language[31]:
				main()
			elif menu.get() == language[32]:
				main()	
			elif mode == "CEF": main()
			else:
				check(menu.get())
				main()
		elif padTriangle("r"):
			x = False
			if menu.get() == language[31]:
				main()
			elif menu.get() == language[32]:
				main()
			elif mode == "CEF": main()
			else:
				duplicate(menu.get())
				main()
		elif padCircle("r"):
			x = False
			if menu.get() == language[31]:
				main()
			elif menu.get() == language[32]:
				main()
			else:
				msg(language[35])
				x1 = True
				while x1 == True:
					delay()
					pad = psp2d.Controller()
					if pad.cross:
						x1 = False
						remove(menu.get())
						main()
					elif pad.start:
						x1 = False
						delete(menu.get())
						main()
					elif pad.triangle:
						x1 = False
						main()
		elif padSelect("r"):
			x = False
			txt([language[36], language[37], language[38], language[39]])
			main()


